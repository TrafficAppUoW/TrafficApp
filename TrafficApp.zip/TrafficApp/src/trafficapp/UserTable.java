/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trafficapp;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author imran
 */
public class UserTable {
    public static void insertToDatabase(Integer id, String userName, String name, Boolean adminStatus, String email, String password){
        Connection connect= DB.getConnection();
        String sql ="INSERT INTO database (ID, userName, name, adminStatus, email, password) VALUES" +"("+ "'"
                +id+"',"
                +"'"+userName
                +"','"+name+"','"+adminStatus+"','"+email+"','"+password
                +"')";
        
        
        try {
            Statement statement = connect.createStatement();
            statement.executeUpdate(sql);
            System.out.println("User " +name + " inserted into database");
            connect.close();
        } catch (Exception ex) {
            System.out.println("[User Table] - error while inserting into database"+ex.getMessage());
        }
    
    }
 public static ResultSet get(String email){
        Connection connect= DB.getConnection();
        
        String sql ="SELECT * FROM database WHERE email= '"+email+"'";
        
        ResultSet result =null;
        try {
            Statement statement = connect.createStatement();
            result = statement.executeQuery(sql);
            connect.close();
            
            
        } catch (Exception ex) {
            System.out.println("[User Table] - error while getting from the database "+ex.getMessage());
        }
    
    return result;
}
   public static ResultSet getLogin(String email, String password){
        Connection connect= DB.getConnection();
        
        String sql ="SELECT * FROM database WHERE email= '"+email+"' AND password='"+password+"'";
        
        ResultSet result =null;
        try {
            Statement statement = connect.createStatement();
            result = statement.executeQuery(sql);
            connect.close();
            
            
        } catch (Exception ex) {
            System.out.println("[User Table] - error while getting from user table "+ex.getMessage());
        }
    
    return result;
}
   
      public static ResultSet ResetPass(String email, String password){
        Connection connect= DB.getConnection();
        
        String sql ="UPDATE database SET password= '"+ password + "' WHERE email= '" + email + "'";
        
        ResultSet result =null;
        try {
            Statement statement = connect.createStatement();
            result = statement.executeQuery(sql);
            connect.close();
            
            
        } catch (Exception ex) {
            System.out.println("[User Table] - error while getting from user table "+ex.getMessage());
        }
    
    return result;
}
      
      public static ResultSet ForgotPass(String email, String userName){
        Connection connect= DB.getConnection();
        
        String sql ="SELECT * FROM database WHERE email= '"+email+"' AND userName='"+userName+"'";
        
        ResultSet result =null;
        try {
            Statement statement = connect.createStatement();
            result = statement.executeQuery(sql);
            connect.close();
            
            
        } catch (Exception ex) {
            System.out.println("[User Table] - error while getting from user table "+ex.getMessage());
        }
    
    return result;
}
static void deleteUser(String email) {
    Connection connect = DB.getConnection();
    
    String sql = "DELETE FROM database WHERE id ="+email;
    
    try{
        Statement statement = connect.createStatement();
        statement.executeUpdate(sql);
        System.out.println("Employee with id: "+email+ " id deleted");
    } catch(Exception ex){
        System.out.println("[USERTABLE] - error when deleting from user table"+ex.getMessage());
    }
    }

    static boolean getAdmin(String username) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
